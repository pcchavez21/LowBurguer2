import { WsService} from "./ws.service";
export const services =[WsService];
export * from "./ws.service";
